Simple Streamer v1.2

INTRODUCTION

The simple streamer Roku app is a simple HLS streamer with a home screen. Go left or right to select an initial stream, and once streaming you can go left/right for selecting other stream, or go up to go back to the home screen.

CONFIGURATION

The simple streamer app is easy to configure. Just edit the videos.xml file to add/remove streams, and to configure text and poster art. The included example should be self explanatory.

SOURCE

The source code for the app lives in the source folder in a file called main.brs(brightscript file). Images and artword are stored in the images folder. The "manifest" file contains the art work references for the poster shown in the channel gallery or channel store.

SUPPORT

For support of this app simply contact the author.

